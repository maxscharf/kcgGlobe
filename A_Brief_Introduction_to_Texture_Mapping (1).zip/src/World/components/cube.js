import {
  BoxBufferGeometry,
  MathUtils,
  Mesh,
  MeshStandardMaterial,
} from 'https://cdn.skypack.dev/three@0.136.2';

function createSphere() {
  const geometry = new SphereBufferGeometry(1, 32, 32); // Adjust the segments as needed
  const material = new MeshStandardMaterial({ color: 'purple' });
  const sphere = new Mesh(geometry, material);

  sphere.rotation.set(-0.5, -0.1, 0.8);

  const radiansPerSecond = MathUtils.degToRad(30);

  // this method will be called once per frame
  sphere.tick = (delta) => {
    // increase the sphere's rotation each frame
    sphere.rotation.z += radiansPerSecond * delta;
    sphere.rotation.x += radiansPerSecond * delta;
    sphere.rotation.y += radiansPerSecond * delta;
  };

  return sphere;
}

export { createSphere };